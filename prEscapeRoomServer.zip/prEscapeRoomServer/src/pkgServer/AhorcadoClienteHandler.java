package pkgServer;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.List;

public class AhorcadoClienteHandler implements Runnable {
    private Socket socket;
    private List<AhorcadoClienteHandler> clientes;
    AhorcadoServer ahorcadoServer;
    private BufferedReader entrada;
    private PrintWriter salida;

    private String palabraSecreta;
    private StringBuilder palabraAdivinada;
    private int intentosRestantes;

    public AhorcadoClienteHandler(Socket socket, List<AhorcadoClienteHandler> clientes, AhorcadoServer ahorcadoServer) {
        this.socket = socket;
        this.clientes = clientes;
        this.ahorcadoServer = ahorcadoServer;
    }

    @Override
    public void run() {
        boolean exit = false;
        try {
            //Inicializa buffers de entrada y salida
            entrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            salida = new PrintWriter(socket.getOutputStream(), true);

            //Si ning�n cliente ha adivinado la palabra, se puede seguir jugando,
            //si ya la ha adivinado alguien aparecer� la soluci�n
            if(!ahorcadoServer.isAdivinado()){
                //Definir propiedades del juego y enviar mensaje de bienvenida
                iniciarJuego();

                //Mientras el juego siga en marcha, se env�a el estado del juego
                while (intentosRestantes > 0 && palabraAdivinada.indexOf("-") != -1) {
                    enviarEstadoJuego();
                    String letra = entrada.readLine().toUpperCase();

                    if (letra.length() == 1 && Character.isLetter(letra.charAt(0))) {
                        procesarIntento(letra.charAt(0));
                    } else if(letra.equals("EXIT")){
                        exit = true;
                        break;
                    }

                }
                if(!exit){
                    //Si el cliente no se ha desconectado antes de acabar el juego se env�a el estado final
                    enviarResultadoFinal();
                }
            }else {
                salida.println("�Felicidades! Ya han adivinado la palabra: CATORCE " );
            }

        } catch (IOException e) {
            if(e.getMessage().equals("Stream closed")){
                System.out.println(e.getMessage());
            }else if(e.getMessage().equals("Connection reset")){
                System.out.println("Contrase�a para salir adivinada.");
            }else{
                e.printStackTrace();
            }
        } finally {
            cerrarConexion();
        }
    }

    //Define las variables del juego,
    private void iniciarJuego() {
        palabraSecreta = "CATORCE";
        palabraAdivinada = new StringBuilder("-".repeat(palabraSecreta.length()));
        intentosRestantes = 7;

        salida.println("�Bienvenido al Juego del Ahorcado!");
        enviarEstadoJuego();
    }

    //Envia al cliente el estado del juego
    private void enviarEstadoJuego() {
        salida.println("Palabra: " + palabraAdivinada);
        salida.println(intentosRestantes);
    }

    private void procesarIntento(char letra) {
        if (palabraSecreta.indexOf(letra) != -1) {
            // La letra est� en la palabra secreta
            for (int i = 0; i < palabraSecreta.length(); i++) {
                if (palabraSecreta.charAt(i) == letra) {
                    palabraAdivinada.setCharAt(i, letra);
                }
            }
        } else {
            // La letra no est� en la palabra secreta
            intentosRestantes--;
            //Env�o la letra para que se a�ada a la lista de letras falladas
            salida.println(letra);
        }
    }

    private void enviarResultadoFinal() {
        if (palabraAdivinada.indexOf("-") == -1) {
            // El jugador adivin� la palabra
            salida.println("�Felicidades! Has adivinado la palabra: " + palabraSecreta);
            ahorcadoServer.setAdivinado();
        } else {
            // El jugador se qued� sin intentos
            salida.println("Lo siento, te has quedado sin intentos. Vuelve a intentarlo m�s tarde");
        }
    }

    private void cerrarConexion() {
        try {
            socket.close();
            clientes.remove(this);
            System.out.println("Cliente desconectado del servidor de ahorcado");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}