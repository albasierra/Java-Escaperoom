package pkgServer;


import javax.swing.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class MainServer {
    private static List<PrintWriter> clients = new ArrayList<>();
    private static final int PUERTO = 4040;
    private static BufferedReader in;
    private static PrintWriter out;
    private static boolean end = false;

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(PUERTO)) {
            System.out.println("Servidor de Escape Room esperando conexiones en el puerto " + PUERTO);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Cliente conectado al servidor de Escape Room ");

                out = new PrintWriter(clientSocket.getOutputStream(), true);
                clients.add(out);

                new Thread(() -> handleClient(clientSocket, out)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Nuevo Juego iniciado.");

    }

    private static void handleClient(Socket clientSocket, PrintWriter out) {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))) {
            // Crear instancias de los servidores y clientes
            AhorcadoServer ahorcadoServer = new AhorcadoServer();
            PasswordServer passwordServer = new PasswordServer();

            // Crear hilos para ejecutar los servidores
            Thread ahorcadoThread = new Thread(ahorcadoServer);
            Thread passwordThread = new Thread(passwordServer);

            while (true) {
                String msg = in.readLine();

                if (msg != null) {
                    if (msg.equals("NUEVO JUEGO")) {
                        System.out.println("Nuevo Juego iniciado");
                        ahorcadoThread.start();
                        passwordThread.start();
                    } else if (msg.equals("FIN")) {
                        System.out.println("Fin del juego");
                        clientSocket.close();
                        System.exit(0);
                    }
                }
            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

}