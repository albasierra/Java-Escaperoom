package pkgServer;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

public class AhorcadoServer implements Runnable {

    private static final int PUERTO = 9005;
    private List<AhorcadoClienteHandler> clientes = new CopyOnWriteArrayList<>();
    private volatile boolean adivinado = false;

    public void run() {
        try (ServerSocket serverSocket = new ServerSocket(PUERTO)) {
            System.out.println("Servidor del Ahorcado esperando conexiones en el puerto " + PUERTO);

            while (true) {
                Socket socket = serverSocket.accept();
                System.out.println("Cliente conectado al servidor de ahorcado");

                AhorcadoClienteHandler clienteHandler = new AhorcadoClienteHandler(socket, clientes, this);
                clientes.add(clienteHandler);
                new Thread(clienteHandler).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("Servidor del Ahorcado detenido.");

    }

    public boolean isAdivinado() {
        return adivinado;
    }

    public void setAdivinado() {
        this.adivinado = true;
    }



}
