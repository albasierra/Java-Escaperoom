package pkgServer;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class PasswordServer implements Runnable{
    private static List<PrintWriter> clients = new ArrayList<>();
    private static final int PUERTO = 5050;


    public void run() {

        try (ServerSocket serverSocket = new ServerSocket(PUERTO)) {
            System.out.println("Servidor de contrase�a esperando conexiones en el puerto " + PUERTO);

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("Cliente conectado al servidor de clave ");

                PrintWriter out = new PrintWriter(clientSocket.getOutputStream(), true);
                clients.add(out);

                new Thread(() -> handleClient(clientSocket, out)).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void handleClient(Socket clientSocket, PrintWriter out) {
        try (BufferedReader in = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()))) {

            out.println("Introduce la clave para salir.");

            String password = "3614"; // Contrase�a predefinida

            while (true) {
                String userInput = in.readLine();

                if (userInput != null) {
                    if (userInput.equals(password)) {
                        notifyClients("�Contrase�a correcta introducida!");
                        break; // Sale del bucle cuando la contrase�a es correcta
                    } else if(userInput.equals("EXIT")){
                        break;
                    }else{
                        out.println("Contrase�a incorrecta. Int�ntalo de nuevo.");
                    }
                }
            }


        } catch (IOException e) {
            if(e.getMessage().equals("Stream closed")){
                System.out.println(e.getMessage());
            }else{
                e.printStackTrace();
            }
        } finally {
            clients.remove(out); // Elimina el PrintWriter cuando el cliente se desconecta
            System.out.println("Cliente desconectado del servidor de Clave");
        }
    }

    private static void notifyClients(String message) {
        for (PrintWriter client : clients) {
            client.println(message);
        }
    }
}
