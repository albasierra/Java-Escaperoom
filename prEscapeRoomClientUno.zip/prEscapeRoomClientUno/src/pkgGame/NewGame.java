package pkgGame;

import pkgClient.Player;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class NewGame {
    private JFrame frame;
    private JPanel panel;
    private JPanel panelBotones;
    private JLabel welcomeLabel;
    private ScheduledExecutorService executorService;
    private static Socket socket;
    private static BufferedReader in;
    private static PrintWriter out;
    
    private JLabel countdownLabel;
    private int countdownSeconds;
    private int minutes;
    private int seconds;
    private Player[] allPlayers = new Player[4];
    private int numberOfPlayers;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                socket = new Socket("localhost", 4040);
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(), true);

                new NewGame().createAndShowGUI();
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        });
    }

    private void createAndShowGUI() {
        frame = new JFrame("Escape Room");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        //Se gestiona el caso en el que el cliente cierre la ventana principal
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent windowEvent) {
                // Avisar al servidor
                out.println("FIN");
                //Cerrar la conexion
                try {
                    socket.close();
                    out.close();
                    in.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
                // Terminar la aplicaci�n
                System.exit(0);
            }
        });
        panel = new JPanel();
        panelBotones = new JPanel();
        panelBotones.setLayout(new GridLayout(2, 2));

        welcomeLabel = new JLabel("�Bienvenido al EscapeRoom! Indique el n�mero de jugadores:");
        panel.add(welcomeLabel);

        countdownLabel = new JLabel("Tiempo restante: ");
        countdownLabel.setFont(new Font("Arial", Font.PLAIN, 24));

        JButton[] playerButtons = new JButton[4];

        for (int i = 0; i < 4; i++) {
            int players = i + 1;
            playerButtons[i] = new JButton(players + " jugador" + (players > 1 ? "es" : ""));
            playerButtons[i].addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    numberOfPlayers = players;
                    startGame();
                }
            });
            panelBotones.add(playerButtons[i]);
        }

        panel.add(panelBotones);

        frame.getContentPane().add(BorderLayout.CENTER, panel);
        frame.setSize(400, 150);
        frame.setVisible(true);
    }

    private void startGame() {
        out.println("NUEVO JUEGO");

        executorService = Executors.newScheduledThreadPool(numberOfPlayers + 1);

        //Reconfiguramos la ventana para mostrar el tiempo restante en lugar del menu
        frame.setVisible(false);
        frame.setSize(400,100);
        panel.remove(panelBotones);
        welcomeLabel.setText("Tiempo restante: ");
        welcomeLabel.setFont(new Font("Arial", Font.PLAIN, 24));
        panel.add(countdownLabel);
        frame.setVisible(true);

        countdownSeconds = 15 * 60; // 15 minutes
        updateCountdownLabel();

        // Crea los hilos de los jugadores.
        for (int i = 0; i < numberOfPlayers; i++) {
            String id = String.valueOf((i + 1));
            Player player = new Player(id, this);
            allPlayers[i] = player;
            executorService.submit(player);
        }

        // Se crea una tarea para actualizar el reloj cada segundo
        executorService.scheduleAtFixedRate(() -> {
            SwingUtilities.invokeLater(() -> {
                countdownSeconds--;
                updateCountdownLabel();
            });
        }, 0, 1, TimeUnit.SECONDS);

        // Se crea una tarea para avisar de que el tiempo ha terminado cuando pasan 15 minutos
        executorService.schedule(() -> {
            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(frame, "Tiempo agotado, �os qued�steis atrapados!");
                closeGame(false);
            });
        }, 15, TimeUnit.MINUTES);
    }

    //Funci�n para actualizar el panel con el contador
    private void updateCountdownLabel() {
        minutes = countdownSeconds / 60;
        seconds = countdownSeconds % 60;
        countdownLabel.setText(String.format("%02d:%02d", minutes, seconds));
    }

    //Se cierra el programa.
    //Si la clave ha sido adivinada, se realizar�n una serie de tareas y
    //si no ha sido adivinada simplemente se cerrar�n los recursos ordenadamente
    public void closeGame(boolean adivinado) {
            executorService.shutdownNow();

        //Si se ha ganado abrir todas las puertas
        if(adivinado){
            for (int i = 0; i<numberOfPlayers;i++){
                allPlayers[i].abrirPuerta();
            }
            JOptionPane.showMessageDialog(null, "�Enhorabuena, hab�is salido de la habitaci�n!", "FIN", JOptionPane.INFORMATION_MESSAGE);
        }

        JOptionPane.showMessageDialog(null, "Tiempo restante: " + String.format("%02d:%02d", minutes, seconds)+" minutos.", "Timer", JOptionPane.INFORMATION_MESSAGE);

        // Cerrar todas las ventanas
        Frame[] frames = JFrame.getFrames();
        for (Frame frame : frames) {
            frame.dispose();
        }

        // Avisar al servidor
        out.println("FIN");
        try {
            socket.close();
            out.close();
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // Terminar la aplicaci�n
        System.exit(0);
    }
}
