package pkgApp;

import javax.swing.*;
import java.awt.*;

public class PanelAhorcado extends JPanel {
    JLabel line1 = new JLabel("  ______");
    JLabel line2 = new JLabel("  |/");
    JLabel line3 = new JLabel("  |");
    JLabel line4 = new JLabel("  |");
    JLabel line5 = new JLabel("  |");
    JLabel line6 = new JLabel("_|_____");

    public PanelAhorcado(){
        Font font = new Font("Arial", Font.PLAIN, 24);

        line1.setFont(font);
        line2.setFont(font);
        line3.setFont(font);
        line4.setFont(font);
        line5.setFont(font);
        line6.setFont(font);


        setLayout(new BoxLayout(this,BoxLayout.Y_AXIS));
        add(line1);
        add(line2);
        add(line3);
        add(line4);
        add(line5);
        add(line6);

    }

    //Dependiendo del n�mero de intentos que queden se muestra un dibujo o otro
    public void actualizarPanel(int intentosRestantes){
        switch (intentosRestantes) {
            case 7:
                line2.setText("  |/");

                break;
            case 6:
                line2.setText("  |/     |");

                break;
            case 5:
                line3.setText("  |     O");
                break;
            case 4:
                line4.setText("  |      |");
                break;
            case 3:
                line4.setText("  |     /|");
                break;
            case 2:
                line4.setText("  |     /|\\");
                break;
            case 1:
                line5.setText("  |     /");
                break;
            case 0:
                line5.setText("  |     / \\");
                break;
        }
    }
}
