package pkgApp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelHabitacion extends JPanel {
    Color MYGREEN = new Color(77,140,21);
    Color MYBLUE = new Color(32,173,205);

    ImageIcon Imagen = new ImageIcon("img/Teclado.jpg");
    Image scaledImage = Imagen.getImage().getScaledInstance(30,40,Image.SCALE_SMOOTH);
    ImageIcon teclado = new ImageIcon(scaledImage);

    ImageIcon Imagen2 = new ImageIcon("img/bombilla.jpg");
    Image scaledImage2 = Imagen2.getImage().getScaledInstance(35,40,Image.SCALE_SMOOTH);
    ImageIcon bombilla = new ImageIcon(scaledImage2);

    JButton buttonLampara = new JButton();
    JButton buttonCama = new JButton();
    JButton buttonSilla = new JButton();
    JButton buttonPuerta = new JButton();
    JButton buttonPista = new JButton();
    JButton buttonSalir = new JButton("EXIT");

    String fondo = "img/Habitacion.jpg";


    public PanelHabitacion(){
        setLayout(null);
        buttonLampara.setBounds(285,25,10,10);
        buttonLampara.setBackground(Color.RED);
        add(buttonLampara);

        buttonSilla.setBounds(150,350,10,10);
        buttonSilla.setBackground(MYGREEN);
        add(buttonSilla);

        buttonCama.setBounds(540,365,10,10);
        buttonCama.setBackground(MYBLUE);
        add(buttonCama);

        buttonPuerta.setBounds(350,270,30,40);
        buttonPuerta.setIcon( teclado);
        add(buttonPuerta);

        buttonPista.setBounds(430,520,35,40);
        buttonPista.setIcon(bombilla);
        add(buttonPista);

        buttonSalir.setBounds(470,520,100,40);
        add(buttonSalir);

    }

    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        ImageIcon background = new ImageIcon(fondo);
        g.drawImage(background.getImage(),0,0,getWidth(),getHeight(),null);
    }

    public  void controlador(ActionListener ctr){
        buttonPuerta.addActionListener(ctr);
        buttonPuerta.setActionCommand("CLAVE");

        buttonCama.addActionListener(ctr);
        buttonCama.setActionCommand("DADO");

        buttonSilla.addActionListener(ctr);
        buttonSilla.setActionCommand("LAPICES");

        buttonLampara.addActionListener(ctr);
        buttonLampara.setActionCommand("AHORCADO");

        buttonPista.addActionListener(ctr);
        buttonPista.setActionCommand("PISTA");

        buttonSalir.addActionListener(ctr);
        buttonSalir.setActionCommand("FIN");

    }

    public void setNewBackground(){
        fondo = "img/Habitacion2.jpg";
        repaint();
    }

}
