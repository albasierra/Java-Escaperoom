package pkgApp;

import javax.swing.*;
import java.awt.*;

public class panelDado extends JPanel {
    public panelDado(){
        setSize(300,300);
    }
    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        ImageIcon background = new ImageIcon("img/Dado.jpg");
        g.drawImage(background.getImage(),0,0,getWidth(),getHeight(),null);
    }
}
