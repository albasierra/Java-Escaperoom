package pkgApp;

import pkgClient.AhorcadoClient;
import pkgClient.PasswordClient;
import pkgClient.Player;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controlador implements ActionListener {

    private JFrame ventanaHabitacion;
    private int pista = 0;
    private boolean palabraAdivinada = false;

    private boolean pAhorcado = true;

    private boolean pClave = true;

    private Player player;

    public Controlador(JFrame ventanaHabitacion, Player player) {
        this.ventanaHabitacion = ventanaHabitacion;
        this.player = player;
    }

    @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getActionCommand().equals("CLAVE")) {
                //Si no se ha abierto ya un cliente de clave por este jugador, se abre.
                if(pClave){
                    SwingUtilities.invokeLater(() -> new PasswordClient(this));
                    pClave = false;
                }
            //Se muestra una foto que contiene una pista
            } else if (e.getActionCommand().equals("DADO")) {
                JFrame frameDado = new JFrame("Aqu� hay un dado.");
                panelDado panelDado = new panelDado();
                frameDado.setSize(300,300);
                frameDado.add(panelDado);
                frameDado.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frameDado.setVisible(true);
            //Se muestra una "foto" generada por ia que contiene una pista
            } else if (e.getActionCommand().equals("LAPICES")) {
                JFrame frameDibujo = new JFrame("�Qu� juego es este?");
                panelDibujo panelDibujo = new panelDibujo();
                frameDibujo.setSize(500,300);
                frameDibujo.add(panelDibujo);
                frameDibujo.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                frameDibujo.setVisible(true);
            } else if (e.getActionCommand().equals("AHORCADO")) {
                //Si la palabra no ha sido adivinada y no hay ya un cliente generado por este jugador conectado al ahorcado se genera
                if(!palabraAdivinada && pAhorcado){
                    SwingUtilities.invokeLater(() -> new AhorcadoClient(this));
                    pAhorcado = false;
                //Si la palabra ya ha sido adivinada se muestra la soluci�n
                }else if (palabraAdivinada){
                    JOptionPane.showMessageDialog(ventanaHabitacion, "�Felicidades! Has adivinado la palabra: CATORCE", "Ahorcado", JOptionPane.INFORMATION_MESSAGE);
                }
                //Al pulsar el bot�n pista se muestra una de las 3 pistas
            } else if (e.getActionCommand().equals("PISTA")) {
                pista++;
                switch (pista) {
                    case 1:
                        JOptionPane.showMessageDialog(ventanaHabitacion, "Encuentra los botones ocultos.", "Pista 1", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    case 2:
                        JOptionPane.showMessageDialog(ventanaHabitacion, "�Qu� le falta al dado?", "Pista 2", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    case 3:
                        JOptionPane.showMessageDialog(ventanaHabitacion, "�Me encanta jugar al 3 en raya!", "Pista 2", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    case 4:
                        JOptionPane.showMessageDialog(ventanaHabitacion, "El orden de la clave est� en los colores de los cuadros", "Pista 3", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    default:
                        JOptionPane.showMessageDialog(ventanaHabitacion, "No quedan m�s pistas", "Error", JOptionPane.ERROR_MESSAGE);
                        break;
                }
            } else if (e.getActionCommand().equals("FIN")) {
                //Si el jugador pulsa el boton de salir se cierra el programa
                player.finDelJuego(false);
            }

        }


    //Estas funciones son para acceder desde los clientes
    public void setPalabraAdivinada(){
        palabraAdivinada = true;
    }

    public void ahorcadoDisconnected(){
        pAhorcado = true;
    }

    public void claveDisconnected(){
        pClave = true;
    }

    public void claveAdivinada(){
        player.finDelJuego(true);
    }
}
