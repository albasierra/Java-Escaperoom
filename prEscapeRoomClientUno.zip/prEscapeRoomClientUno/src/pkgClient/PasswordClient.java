package pkgClient;
import pkgApp.Controlador;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

//El cliente es una ventana
public class PasswordClient extends JFrame {
    private PrintWriter out;
    private BufferedReader in;

    private JTextField passwordField;

    JPanel tecladoPanel = new JPanel(new GridLayout(4, 3));

    Controlador controlador;

    //Se le pasa al cliente el manejador del controlador para poder acceder a sus funciones
    public PasswordClient(Controlador controlador) {

        //Crea el frame con este t�tulo
        super("Cliente de Contrase�as");

        this.controlador = controlador;

        passwordField = new JTextField();
        passwordField.setEditable(false);

        //Se crean los action listener para cada bot�n
        for (int i = 1; i <= 9; i++) {
            JButton button = new JButton(Integer.toString(i));
            button.addActionListener(new TecladoActionListener());
            tecladoPanel.add(button);
        }
        JButton zeroButton = new JButton("0");
        zeroButton.addActionListener(new TecladoActionListener());
        tecladoPanel.add(zeroButton);

        JButton submitButton = new JButton("Enviar");
        submitButton.addActionListener(new EnviarActionListener());

        setLayout(new BorderLayout());
        add(passwordField, BorderLayout.NORTH);
        add(tecladoPanel, BorderLayout.CENTER);
        add(submitButton, BorderLayout.SOUTH);

        setSize(300, 400);
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent windowEvent) {
                disconnect();
            }
        });
        setLocationRelativeTo(null);
        setVisible(true);

        conectarAlServidor();
    }

    //En esta funci�n nos conectamos al servidor y gestionamos la comunicaci�n
    private void conectarAlServidor() {
        try {
            Socket socket = new Socket("localhost", 5050);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            //Se crea un hilo para que el resto de procesos no se bloqueen al abrir el panel de clave
            new Thread(()-> {

                try {
                    while (true) {
                        String mensaje = in.readLine();
                        //Comprobamos que el mensaje no est� vac�o
                        if (mensaje != null) {
                            //Si se acierta la clave el juego ha acabado y se sale de la habitaci�n
                            if (mensaje.equals("�Contrase�a correcta introducida!")){
                                disconnect();
                                controlador.claveAdivinada();
                                break;
                            }
                            //Se muestra en un panel el mensaje recibido
                            JOptionPane.showMessageDialog(tecladoPanel, mensaje, "Ahorcado", JOptionPane.INFORMATION_MESSAGE);
                        }
                    }
                } catch (IOException e) {
                    if(e.getMessage().equals("Socket closed")){
                        System.out.println("Panel de contrase�a cerrado");
                    }else{
                        e.printStackTrace();
                    }
                }
            }).start();
        } catch (IOException e) {
            //Se maneja el caso en el que el servidor no hab�a sido inicializado previamente
            if(e.getMessage().equals("Connection refused: connect")){
                JOptionPane.showMessageDialog(tecladoPanel, "No se ha podido conectar con el servidor. Por favor, comprueba que el servidor existe.", "Ahorcado", JOptionPane.INFORMATION_MESSAGE);
                System.exit(130);
            }
            e.printStackTrace();
        }
    }

    //Se transforman las pulsaciones de los botones en d�gitos y se a�aden al passwordField
    private class TecladoActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            JButton button = (JButton) e.getSource();
            String digit = button.getText();
            SwingUtilities.invokeLater(() -> passwordField.setText(passwordField.getText() + digit));
        }
    }

    //Se lee lo que haya en el passwordField y se le env�a al servidor para ser comprobado
    private class EnviarActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String password = passwordField.getText();
            out.println(password);
            passwordField.setText(""); // Limpiar el campo despu�s de enviar la contrase�a
        }
    }

    //Se avisa al servidor y al controlador de que voy a desconectarme y se cierran la comunicaci�n y la ventana
    private void disconnect() {
        SwingUtilities.invokeLater(() -> {
            try {
                controlador.claveDisconnected();
                out.println("EXIT");  // Enviar mensaje al servidor indicando desconexi�n
                out.close();
                in.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            dispose();  // Cerrar la ventana
        });
    }

}
