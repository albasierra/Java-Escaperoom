package pkgClient;

import pkgApp.Controlador;
import pkgApp.PanelHabitacion;
import pkgGame.NewGame;

import javax.swing.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class Player implements Runnable{
    private PanelHabitacion habitacion;
    private String id;
    private NewGame newGame;
    public Player(String  id, NewGame newGame) {
        this.id = id;
        this.newGame = newGame;
    }

    @Override
    public void run() {
        JFrame ventanaHabitacion = new JFrame("Jugador "+id);
        habitacion = new PanelHabitacion();
        Controlador ctr = new Controlador(ventanaHabitacion,this);
        habitacion.controlador(ctr);
        ventanaHabitacion.setContentPane(habitacion);
        ventanaHabitacion.setSize(600, 600);
        ventanaHabitacion.setVisible(true);
        ventanaHabitacion.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        ventanaHabitacion.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent windowEvent) {
                finDelJuego(false);
            }
        });

    }

    public void finDelJuego(boolean i) {
        newGame.closeGame(i);
    }

    public void abrirPuerta(){
        habitacion.setNewBackground();
    }
}
