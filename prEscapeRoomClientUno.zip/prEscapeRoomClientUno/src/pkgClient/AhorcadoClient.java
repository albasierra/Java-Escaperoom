package pkgClient;

import pkgApp.Controlador;
import pkgApp.PanelAhorcado;

import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

//El cliente es una ventana
public class AhorcadoClient extends JFrame {
    private BufferedReader entrada;
    private PrintWriter salida;

    private JLabel palabraLabel;
    private JTextField letraTextField;
    private JLabel falladasText;


    private PanelAhorcado panelAhorcado;
    private Controlador controlador;
    private String[] letras = {" "," "," "," "," "," "," "};
    private int intentos = 0;


    //Se le pasa al cliente el manejador del controlador para poder acceder a sus funciones
    public AhorcadoClient(Controlador controlador) {
        super("Juego del Ahorcado");

        this.controlador = controlador;

        Font font = new Font("Arial", Font.PLAIN, 18);

        palabraLabel = new JLabel("Conectando al servidor...");

        //Panel para mostrar las letras falladas
        JLabel falladasLabel = new JLabel("Letras falladas:    ");
        falladasText = new JLabel();
        JPanel panelFalladas = new JPanel();
        panelFalladas.setLayout(new GridLayout(2,1));

        panelFalladas.add(falladasLabel);
        panelFalladas.add(falladasText);

        //Panel para introducir los intentos de letras
        JLabel in = new JLabel("Introduce una letra: ");
        letraTextField = new JTextField(1);
        JPanel panelRespuestas = new JPanel();
        panelRespuestas.setLayout(new GridLayout(1,2));

        panelRespuestas.add(in);
        panelRespuestas.add(letraTextField);

        //Panel con el dibujo del ahorcado
        panelAhorcado = new PanelAhorcado();

        palabraLabel.setFont(font);
        in.setFont(font);
        letraTextField.setFont(font);
        falladasText.setFont(font);
        falladasLabel.setFont(font);

        //si se pulsa enter en el textfield se env�a el intento al servidor
        letraTextField.addActionListener(e -> enviarIntento());

        setLayout(new BorderLayout());
        add(panelAhorcado, BorderLayout.CENTER);
        add(palabraLabel, BorderLayout.NORTH);
        add(panelRespuestas, BorderLayout.SOUTH);
        add(panelFalladas, BorderLayout.EAST);

        setSize(400, 300);
        //Nos aseguramos de que el cliente se desconecte al cerrar la ventana
        setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent windowEvent) {
                disconnect();
            }
        });

        setVisible(true);

        conectarAlServidor();
    }

    //En esta funci�n nos conectamos al servidor y gestionamos la comunicaci�n
    private void conectarAlServidor() {
        try {
            Socket socket = new Socket("localhost", 9005);
            entrada = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            salida = new PrintWriter(socket.getOutputStream(), true);

            //Se crea un hilo para que el resto de procesos no se bloqueen al abrir este minijuego
            new Thread(() -> {
                try {
                    while (true) {
                        String mensaje = entrada.readLine();
                        //Si se ha podido leer alg�n mensaje:
                        if (mensaje != null) {

                            //si es el mensaje de bienvenida o uno de los mensajes del proceso se actualiza lo mostrado en el panel
                            if (mensaje.startsWith("Palabra") || mensaje.startsWith("�B")) {
                                actualizarPalabra(mensaje);
                            //si es el mensaje de haber acertado o de haberse quedado sin intentos se gestiona y se muestra un mensaje popup
                            } else if(mensaje.startsWith("�F") || mensaje.startsWith("Lo")){
                                //Si la palabra se ha adivinado avisamos al controlador
                                if(mensaje.startsWith("�F")){
                                    controlador.setPalabraAdivinada();
                                //si la palabra no se ha adivinado el mu�eco es ahorcado
                                }else {
                                    panelAhorcado.actualizarPanel(0);
                                }
                                JOptionPane.showMessageDialog(super.rootPane, mensaje, "Ahorcado", JOptionPane.INFORMATION_MESSAGE);
                                //finalmente desconectamos al cliente
                                disconnect();
                                break;
                            //Si el mensaje es una letra significa que la hemos fallado y la a�adimos a la lista de las letras falladas
                            } else if(mensaje.matches("[A-Z]")){
                                actualizarFalladas(mensaje);
                            //El otro tipo de mensaje que se puede recibir es un n�mero que indica el n�mero de intentos que nos quedan para que actualicemos el panel
                            }else{
                                intentos = Integer.parseInt(mensaje);
                                panelAhorcado.actualizarPanel(intentos);
                            }
                        }
                    }
                } catch (IOException e) {
                    if(e.getMessage().equals("Socket closed")) {
                        System.out.println("Panel de ahorcado cerrado");
                    }else {
                        e.printStackTrace();
                    }
                }
            }).start();
        } catch (IOException e) {
            //Se maneja el caso en el que el servidor no hab�a sido inicializado previamente
            if(e.getMessage().equals("Connection refused: connect")){
                JOptionPane.showMessageDialog(panelAhorcado, "No se ha podido conectar con el servidor. Por favor, comprueba que el servidor existe.", "Ahorcado", JOptionPane.INFORMATION_MESSAGE);
                System.exit(130);
            }
            e.printStackTrace();
        }
    }

    //Se lee la letra introducida en el textfield, se pasa a may�sculas y se env�a al servidor
    private void enviarIntento() {
        String letra = letraTextField.getText().toUpperCase();
        if (!letra.isEmpty() && letra.matches("[A-Z]")) {
            salida.println(letra);
        }
        letraTextField.setText("");
    }

    //Se actualiza la label con la palabra con huecos recibida del servidor
    private void actualizarPalabra(String mensaje) {
        SwingUtilities.invokeLater(() -> palabraLabel.setText(mensaje));
    }

    //Se actualiza el espacio con las letras falladas
    private void actualizarFalladas(String letra){
        StringBuffer l = new StringBuffer();
        letras[7-intentos]= letra;
        for (int i =0; i<7; i++){
            l.append(" ").append(letras[i]);
        }
        SwingUtilities.invokeLater(() -> falladasText.setText(l.toString()));

    }

    //Se avisa al servidor y al controlador de que voy a desconectarme y se cierran la comunicaci�n y la ventana
    private void disconnect() {
        SwingUtilities.invokeLater(() -> {
            try {
                controlador.ahorcadoDisconnected();
                salida.println("EXIT");  // Enviar mensaje al servidor indicando desconexi�n
                salida.close();
                entrada.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            dispose();  // Cerrar la ventana
        });
    }

}
